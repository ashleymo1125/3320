    <?php
                    
                    function get_array_data($fileName) {
            
            $handle = fopen($fileName,"r");
            while (!feof($handle)) {
                $value = fgets($handle); //read a value (one line)
                $value = str_replace(array("\n", "\r"), '', $value);  //remove newlines
                if(!feof($handle)) {
                    $values[] = $value;		
                }
            }
            fclose($handle);
            return $values;
        }
                    
                    
                       function write_table($handle, $database, $table, $columns, $values) {
            fwrite($handle, "use $database;\n\n");
            fwrite($handle, "SET AUTOCOMMIT=0;\n\n");
            //from DBeaver
            //INSERT INTO moviestore4.actor (first_name,last_name) VALUES ('Fred','Schwab');
            fwrite($handle, "INSERT INTO $database.$table (");
            for($i = 0; $i < sizeof($columns); $i++) {
                fwrite($handle, $columns[$i]);
                if($i!= sizeof($columns)-1) { // if not the last value, print comma
                    fwrite($handle, ",");
                }
            }
            fwrite($handle, ") VALUES\n");
            
            for($i = 0; $i < sizeof($values); $i++) {
                fwrite($handle, "(");
                for($j = 0; $j < sizeof($values[$i]); $j++) {
                    fwrite($handle, $values[$i][$j]);
                    if($j != sizeof($values[$i]) - 1) { //if not at last value, print comma
                       fwrite($handle, ","); 
                    }
                }
                if($i != sizeof($values)-1) { //not at last one
                    fwrite($handle, "),\n");
                } else {
                    fwrite($handle, ");\n\nCOMMIT;");
                }

            }
        }
                $customer_columns = array("customer_id", "first_name", "last_name", "email", "phone", "address_id");
                $order_column = array("order_id", "customer_id", "address_id");
                $product_column = array("product_id","product_name", "description", "weight", "base_cost");
                $order_item_column = array("order_id", "product_id", "quantity", "price");
                $address_column = array("address_id", "street", "city", "states", "zip");
                $warehouse_column = array("warehouse_id", "name", "address_id");
                $product_warehouse_column = array("product_id", "warehouse_id");
                
                    
                    
                    
                    

  

 $address_columns = array("address_id", "street", "city", "state", "zip");
 $customer_coulmn = array("customer_id", "first_name", "last_name", "email","phone","address_id");
                
//echo rand(1,300).$streetName[rand(0,count($streetName)-1)].$streetType[rand(0,count($streetType)-1)];

                $firstNames = get_array_data("first_names.txt");
                $lastNames = get_array_data("last_names.txt"); 
                $street_name = get_array_data("street_names.txt");
                $street_type = get_array_data("street_types.txt");
                $city = get_array_data("city_names.txt");
                $product = get_array_data("products.txt");
                $states = get_array_data("states.txt");
                $domain = get_array_data("domains.txt");
                $warehouse_name = get_array_data("warehouse.txt");
                $product_desc = get_array_data("productDescription.txt");
                $digits = 5;
                $phone_digit =10;

//echo print_r($lastNames);
echo print_r($domain). "<h1> Hell0 </h1>";
    
    // ADDRESS
            for($i = 0; $i < 151; $i++) 
         {
                
                $theStreet =  "'".rand(1,299)." ".$street_name[rand(0, count($street_name)-1)]." ".$street_type[rand(0, count($street_type)-1)]."'";
                $address[$i][0] = $i; 
                        $address[$i][1] = $theStreet;
                        $address[$i][2] = "'".$city[rand(0, count($city)-1)]."'";
                        $address[$i][3] = "'".$states[rand(0, count($states)-1)]."'";
                        $address[$i][4] = "'".(rand(pow(10, $digits-1), pow(10, $digits)-1))."'";
                    
          
        }

// CUSTOMER
        for($i = 0; $i < 101; $i++)
        {
            $theFirstName = $firstNames[rand(0,count($firstNames)-1)];
            $theLastName = $lastNames[rand(0,count($lastNames)-1)];
            
            $customers[$i][0] = $i;
            $customers[$i][1] = "'".$theFirstName."'";
            $customers[$i][2] = "'".$theLastName."'";
            $customers[$i][3] = "'".$theFirstName.'.'.$theLastName.$domain[rand(0, count($domain)-1)]."'";
            $customers[$i][4] = "'".rand(1999999999,5999999999)."'";
            // FORIEGN KEY
            $customers[$i][5] = "'".rand(1,151)."'";
            
            
            
        }
    

       $handle = fopen("data.sql", "w");
        //write the data
        write_table($handle, "SuperStore", "address", $address_columns, $address);
        write_table($handle, "SuperStore", "customer", $customer_columns, $customers);
        
        fclose($handle);
                
        
                

   ?>
